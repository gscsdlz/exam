﻿#include "answerinfo.h"

AnswerInfo::AnswerInfo()
{

}
