﻿#include "examinfodao.h"

ExamInfoDao::ExamInfoDao()
{

}
