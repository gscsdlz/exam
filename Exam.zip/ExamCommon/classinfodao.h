﻿#ifndef CLASSINFODAO_H
#define CLASSINFODAO_H

#include "dao.h"

class ClassInfoDao : public DAO
{
public:
    ClassInfoDao();
};

#endif // CLASSINFODAO_H
