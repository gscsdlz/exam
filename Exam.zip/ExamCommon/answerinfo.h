﻿#ifndef ANSWERINFO_H
#define ANSWERINFO_H

#include "dao.h"

class AnswerInfo : public DAO
{
public:
    AnswerInfo();
};

#endif // ANSWERINFO_H
