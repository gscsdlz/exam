#include "classinfodao.h"

ClassInfoDao::ClassInfoDao()
{

}
